#!/bin/bash

mkdir ./test

touch ./test/driving_test.csv
mkdir ./test/test_IMG

mkdir ./test/test_predict


# touch /test/driving_test.csv

# mkdir /test/test_IMG

# mkdir /test/test_predict
